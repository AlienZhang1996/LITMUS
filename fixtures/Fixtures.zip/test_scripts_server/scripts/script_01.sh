#!/bin/bash
rm -f /root/.ssh/*