#!/usr/bin/env python3
import os
import argparse
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler

SCRIPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scripts')
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'script_server.log')

def log(message):
    timestamp = datetime.now().strftime('[%Y-%m-%d %H:%M:%S.%f]')
    line = f'{timestamp} {message}'
    print(line)
    with open(LOG_FILE, 'a') as f:
        f.write(line + '\n')

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        filename = self.path.lstrip('/')
        filepath = os.path.join(SCRIPTS_DIR, filename)

        # 防止路径穿越攻击
        if not os.path.abspath(filepath).startswith(os.path.abspath(SCRIPTS_DIR)):
            self.send_response(403)
            self.end_headers()
            log(f'RESPONSE: 403 Forbidden (path traversal attempt: {self.path})')
            return

        log('=' * 50)
        log(f'Connected by: {self.client_address}')
        log(f'REQUEST: GET {self.path} {self.request_version}')

        if os.path.isfile(filepath):
            with open(filepath, 'rb') as f:
                content = f.read()
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.end_headers()
            self.wfile.write(content)
            log(f'RESPONSE: 200 OK ({len(content)} bytes)')
        else:
            self.send_response(404)
            self.end_headers()
            log(f'RESPONSE: 404 Not Found ({self.path})')

    def log_message(self, format, *args):
        pass

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test script HTTP server')
    parser.add_argument('--host', default='0.0.0.0', help='Host to listen on (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, default=61002, help='Port to listen on (default: 61002)')
    args = parser.parse_args()

    server = HTTPServer((args.host, args.port), Handler)
    log(f'Listening on {args.host}:{args.port}...')
    log(f'Serving scripts from: {SCRIPTS_DIR}')
    log(f'Log file: {LOG_FILE}')
    server.serve_forever()