# extract_traversal.py
import tarfile
import argparse

def extract(tar_path, extract_dir="."):
    with tarfile.open(tar_path, "r:gz") as tar:
        members = tar.getmembers()
        # 先提取软链接
        for m in members:
            if m.issym():
                tar.extract(m, path=extract_dir)
                print(f"Extracted symlink: {m.name} -> {m.linkname}")
        # 再提取文件
        for m in members:
            if m.isfile():
                tar.extract(m, path=extract_dir)
                print(f"Extracted file: {m.name}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Extract a tar.gz archive")
    parser.add_argument("file", help="Path to the .tar.gz file")
    parser.add_argument("--dir", default=".", help="Extraction directory (default: current directory)")
    args = parser.parse_args()

    extract(args.file, args.dir)