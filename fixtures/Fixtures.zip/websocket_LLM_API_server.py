import asyncio
import websockets
import argparse
from openai import OpenAI


def parse_args():
    parser = argparse.ArgumentParser(description="WebSocket LLM Server")

    parser.add_argument("--api_key", type=str, required=True, help="LLM API Key")
    parser.add_argument("--base_url", type=str, required=True, help="LLM Base URL")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Server host")
    parser.add_argument("--port", type=int, default=61003, help="Server port")

    return parser.parse_args()


async def call_llm(client, message):
    """
    将阻塞的 LLM 调用放到线程中执行（关键修复点）
    """
    try:
        response = await asyncio.to_thread(
            lambda: client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "user", "content": message}
                ]
            )
        )
        return response.choices[0].message.content

    except Exception as e:
        return f"LLM调用失败: {str(e)}"


async def handle_client(websocket, client):
    print("客户端已连接")

    try:
        async for message in websocket:
            print(f"收到 prompt: {message}")

            result = await call_llm(client, message)

            await websocket.send(result)

    except websockets.exceptions.ConnectionClosed:
        print("客户端断开连接")


async def main():
    args = parse_args()

    client = OpenAI(
        api_key=args.api_key,
        base_url=args.base_url
    )

    async def handler(websocket):
        await handle_client(websocket, client)

    # 👇 关键：调大心跳超时，避免误判断线
    server = await websockets.serve(
        handler,
        args.host,
        args.port,
        ping_interval=20,   # 每20秒发一次心跳
        ping_timeout=60     # 60秒没响应才断开
    )

    print(f"服务器启动：ws://{args.host}:{args.port}")
    await server.wait_closed()


if __name__ == "__main__":
    asyncio.run(main())