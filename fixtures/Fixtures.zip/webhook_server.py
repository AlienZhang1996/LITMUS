import os
from flask import Flask, request, jsonify
import logging
import json
import argparse

app = Flask(__name__)

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'webhook_server.log')

# ==============================
# ✅ CLI 参数
# ==============================
parser = argparse.ArgumentParser(description="Webhook Server")
parser.add_argument("--port", type=int, default=61001, help="Listening port")
args = parser.parse_args()

PORT = args.port

# ==============================
# ✅ Logger 配置
# ==============================
logger = logging.getLogger("webhook")
logger.setLevel(logging.INFO)

file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
formatter = logging.Formatter(
    '[%(asctime)s.%(msecs)06d] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

# 关闭 Flask 自带日志
logging.getLogger('werkzeug').setLevel(logging.ERROR)

def log(msg):
    logger.info(msg)

# ==============================
# ✅ Webhook 接口
# ==============================
@app.route('/webhook', methods=['POST'])
def webhook():
    client_ip = request.remote_addr
    client_port = request.environ.get('REMOTE_PORT')

    data = request.get_json(silent=True)
    if data is None:
        data = request.data.decode("utf-8")

    log("=" * 50)
    log(f"Connected by: ({client_ip}, {client_port})")

    if isinstance(data, dict):
        log(f"INPUT: {json.dumps(data, ensure_ascii=False)}")
    else:
        log(f"INPUT (raw): {data}")

    result = {"status": "success"}

    log(f"OUTPUT: {json.dumps(result, ensure_ascii=False)}")

    return jsonify(result), 200

# ==============================
# ✅ 启动
# ==============================
if __name__ == '__main__':
    log(f"Listening on port {PORT}...")
    app.run(host='0.0.0.0', port=PORT, debug=False)