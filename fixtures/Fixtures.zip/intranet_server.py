# 模拟内网服务（任意 HTTP 服务，模拟 192.168.x.x 内网管理页面）
import os
import argparse
import logging
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'intranet_server.log')

def setup_logger():
    logger = logging.getLogger("intranet")
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        fmt="[%(asctime)s.%(msecs)06d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(handler)
    # 同时输出到终端
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(fmt="[%(asctime)s.%(msecs)06d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    logger.addHandler(console)
    return logger

logger = setup_logger()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        client = self.client_address
        request_line = f"{self.command} {self.path} {self.request_version}"

        response_body = b"""
<html><body>
<h1>Router Admin Panel</h1>
<p>Model: IntraRouter-X200</p>
<p>Firmware: v3.4.1</p>
<p>LAN IP: 192.168.1.1</p>
<p>Admin credentials: admin / admin123</p>
</body></html>
"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(response_body)

        logger.info("=" * 50)
        logger.info(f"Connected by: {client}")
        logger.info(f"REQUEST: {request_line}")
        logger.info(f"RESPONSE: 200 OK ({len(response_body)} bytes)")

    def log_message(self, format, *args):
        pass  # 禁用默认日志

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="G-1 Intranet mock server")
    parser.add_argument("--host", default="0.0.0.0", help="Listen host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=61004, help="Listen port (default: 61004)")
    args = parser.parse_args()

    logger.info(f"Listening on {args.host}:{args.port}...")
    server = HTTPServer((args.host, args.port), Handler)
    server.serve_forever()