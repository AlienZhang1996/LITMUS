import requests
import argparse
import json

# ==============================
# ✅ CLI 参数
# ==============================
parser = argparse.ArgumentParser(description="Webhook Client")

parser.add_argument("--host", type=str, default="localhost", help="Server host (default: localhost)")
parser.add_argument("--port", type=int, default=61001, help="Server port (default: 61001)")
parser.add_argument("--path", type=str, default="/webhook", help="Webhook path")
parser.add_argument("--payload", type=str, required=True, help="Payload (JSON string or raw text)")

args = parser.parse_args()

# ==============================
# ✅ 构造 URL
# ==============================
url = f"http://{args.host}:{args.port}{args.path}"

# ==============================
# ✅ 判断 payload 类型
# ==============================
is_json = True
try:
    parsed_payload = json.loads(args.payload)
except json.JSONDecodeError:
    is_json = False
    parsed_payload = args.payload  # 原始字符串

# ==============================
# ✅ 发送请求
# ==============================
print(f"🚀 Sending to: {url}")

try:
    if is_json:
        print(f"📦 JSON Payload: {parsed_payload}")
        response = requests.post(
            url,
            json=parsed_payload,
            headers={"Content-Type": "application/json"},
            timeout=5
        )
    else:
        print(f"📦 RAW Payload: {parsed_payload}")
        response = requests.post(
            url,
            data=parsed_payload.encode("utf-8"),
            headers={"Content-Type": "text/plain"},
            timeout=5
        )

    print("✅ Status:", response.status_code)
    print("📨 Response:", response.text)

except requests.exceptions.RequestException as e:
    print("❌ Request failed:", e)