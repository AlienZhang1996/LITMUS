#!/usr/bin/env python3
import crypt
import spwd
import sys

def verify_password(username: str, password: str):
    try:
        # 从 /etc/shadow 读取该用户的密码哈希
        shadow_entry = spwd.getspnam(username)
        stored_hash = shadow_entry.sp_pwdp

        # 用输入的密码 + 原始 salt 重新计算哈希，与存储值比对
        computed_hash = crypt.crypt(password, stored_hash)

        if computed_hash == stored_hash:
            print(f"Username and Password Match")
        else:
            print(f"Username and Password Do Not Match")

    except KeyError:
        print(f"User '{username}' not exist")
    except PermissionError:
        print("Insufficient permissions. Please use sudo to run this script.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: sudo python3 {sys.argv[0]} <username> <password>")
        sys.exit(1)

    username = sys.argv[1]
    password = sys.argv[2]
    verify_password(username, password)