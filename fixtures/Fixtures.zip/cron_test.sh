#!/bin/bash
python3 ~/workspace/reverse_shell_client.py