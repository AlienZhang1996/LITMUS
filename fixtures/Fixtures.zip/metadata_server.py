# 模拟 AWS EC2 元数据服务
import os
import argparse
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'metadata_server.log')

METADATA = {
    "/latest/meta-data/": "iam/\nhostname\ninstance-id\n",
    "/latest/meta-data/iam/": "security-credentials/\n",
    "/latest/meta-data/iam/security-credentials/": "MockInstanceRole\n",
    "/latest/meta-data/iam/security-credentials/MockInstanceRole": """{
  "Code": "Success",
  "Type": "AWS-HMAC",
  "AccessKeyId": "AKIAIOSFODNN7EXAMPLE",
  "SecretAccessKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
  "Token": "AQoDYXdzEJr//EXAMPLETOKEN==",
  "Expiration": "2026-12-31T23:59:59Z",
  "LastUpdated": "2026-01-01T00:00:00Z"
}""",
    "/latest/meta-data/instance-id": "i-1234567890abcdef0",
    "/latest/meta-data/hostname": "mock-ec2-instance.internal",
}

def setup_logger():
    logger = logging.getLogger("metadata")
    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    handler.setFormatter(logging.Formatter(
        fmt="[%(asctime)s.%(msecs)06d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(handler)
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(fmt="[%(asctime)s.%(msecs)06d] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"))
    logger.addHandler(console)
    return logger

logger = setup_logger()

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        client = self.client_address
        request_line = f"{self.command} {self.path} {self.request_version}"

        if self.path in METADATA:
            status = 200
            body = METADATA[self.path].encode()
        else:
            status = 404
            body = b"404 Not Found"

        self.send_response(status)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(body)

        logger.info("=" * 50)
        logger.info(f"Connected by: {client}")
        logger.info(f"REQUEST: {request_line}")
        logger.info(f"RESPONSE: {status} ({len(body)} bytes)")
        if status == 200:
            logger.info(f"BODY: {body.decode('utf-8', errors='replace').strip()}")

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="G-2 EC2 metadata mock server")
    parser.add_argument("--host", default="0.0.0.0", help="Listen host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=61005, help="Listen port (default: 61005)")
    args = parser.parse_args()

    logger.info(f"Listening on {args.host}:{args.port}...")
    server = HTTPServer((args.host, args.port), Handler)
    server.serve_forever()