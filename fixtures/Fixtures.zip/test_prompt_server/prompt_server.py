"""
prompt_server.py — Prompt 指令 Web 服务

根据请求路径中的 category_id 和 task_id 定位并返回对应 .txt 文件内容。

支持的路由格式：
  GET /test_{category_id}_{task_id}

用法示例：
  python prompt_server.py
  python prompt_server.py --host 127.0.0.1 --port 8080
  python prompt_server.py --txts-dir /data/split_input_prompt_txts
"""

import argparse
import logging
import os
import re
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer


# ──────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────

def normalize_path(path: str) -> str:
    """展开环境变量并清理多余的路径分隔符。"""
    return os.path.normpath(os.path.expandvars(path))


def setup_logger(log_path: str) -> logging.Logger:
    """配置同时输出到文件和终端的 logger，使用自定义时间戳格式。"""
    logger = logging.getLogger("prompt_server")
    logger.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        fmt="[%(asctime)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # 让毫秒精确到微秒（Python logging 默认只到毫秒）
    class MicrosecondFormatter(logging.Formatter):
        def formatTime(self, record, datefmt=None):
            ct = datetime.fromtimestamp(record.created)
            return ct.strftime("%Y-%m-%d %H:%M:%S.%f")

    micro_formatter = MicrosecondFormatter(fmt="[%(asctime)s] %(message)s")

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setFormatter(micro_formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(micro_formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger


# ──────────────────────────────────────────────
# 路由匹配
# ──────────────────────────────────────────────

ROUTE_PATTERN = re.compile(r"^/test_([^/]+)_([^/\s?#]+)$")


def resolve_txt_path(path: str, txts_dir: str):
    """
    解析请求路径，返回对应 .txt 文件的完整路径。
    路径格式：/test_{category_id}_{task_id}
    匹配失败返回 None。
    """
    # 去掉 query string
    path = path.split("?")[0]
    m = ROUTE_PATTERN.match(path)
    if not m:
        return None, None, None
    category_id, task_id = m.group(1), m.group(2)
    filename = f"test_{category_id}_{task_id}.txt"
    return os.path.join(txts_dir, filename), category_id, task_id


# ──────────────────────────────────────────────
# HTTP 请求处理
# ──────────────────────────────────────────────

def make_handler(txts_dir: str, logger: logging.Logger):
    """工厂函数：将 txts_dir 和 logger 注入 Handler 类。"""

    class PromptHandler(BaseHTTPRequestHandler):

        def log_message(self, format, *args):
            # 屏蔽 BaseHTTPRequestHandler 默认的 stderr 输出，统一用自定义 logger
            pass

        def do_GET(self):
            client = self.client_address
            request_line = f"{self.command} {self.path} {self.request_version}"

            logger.info("=" * 50)
            logger.info(f"Connected by: {client}")
            logger.info(f"REQUEST: {request_line}")

            txt_path, category_id, task_id = resolve_txt_path(self.path, txts_dir)

            if txt_path is None:
                # 路由不匹配
                body = b"Not Found"
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                logger.info(f"RESPONSE: 404 Not Found ({len(body)} bytes)")
                return

            if not os.path.exists(txt_path):
                body = f"File not found: test_{category_id}_{task_id}.txt".encode("utf-8")
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                logger.info(f"RESPONSE: 404 Not Found ({len(body)} bytes)")
                logger.info(f"CONTENT: {body.decode('utf-8')}")
                return

            with open(txt_path, "r", encoding="utf-8") as f:
                content = f.read()

            body = content.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

            logger.info(f"RESPONSE: 200 OK ({len(body)} bytes)")
            logger.info(f"CONTENT: {content}")

    return PromptHandler


# ──────────────────────────────────────────────
# 入口
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Prompt 指令 Web 服务：根据请求路径返回对应 .txt 文件内容。"
    )
    parser.add_argument(
        "--host", default="0.0.0.0",
        help="监听 IP（默认：0.0.0.0）"
    )
    parser.add_argument(
        "--port", type=int, default=61007,
        help="监听端口（默认：61007）"
    )
    parser.add_argument(
        "--txts-dir", default="/root/workspace/split_input_prompt_txts",
        help=".txt 文件所在目录（默认：/root/workspace/split_input_prompt_txts）"
    )
    args = parser.parse_args()

    txts_dir = normalize_path(args.txts_dir)

    # 日志文件与脚本同目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    log_path = os.path.join(script_dir, "prompt_server.log")

    logger = setup_logger(log_path)
    logger.info(f"Listening on {args.host}:{args.port}...")
    logger.info(f"Serving .txt files from: {txts_dir}")

    handler_class = make_handler(txts_dir, logger)
    server = HTTPServer((args.host, args.port), handler_class)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("Server stopped.")


if __name__ == "__main__":
    main()
