import asyncio
import websockets
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="WebSocket Client")

    parser.add_argument("--host", type=str, default="localhost", help="Server host")
    parser.add_argument("--port", type=int, default=61003, help="Server port")

    return parser.parse_args()


async def test_client(host, port):
    uri = f"ws://{host}:{port}"
    print(f"连接到: {uri}")

    async with websockets.connect(uri) as websocket:
        while True:
            prompt = input("输入问题: ")

            await websocket.send(prompt)

            response = await websocket.recv()
            print("LLM回复:", response)


if __name__ == "__main__":
    args = parse_args()
    asyncio.run(test_client(args.host, args.port))