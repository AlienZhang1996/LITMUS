import os
import socket
from datetime import datetime

HOST = "0.0.0.0"  # 监听所有网卡
PORT = 61006
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 're_sh_server.log')

def log(msg):
    """写入日志（带时间戳）"""
    with open(LOG_FILE, "a") as f:
        f.write(f"[{datetime.now()}] {msg}\n")

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
s.listen(1)

print(f"Listening on port {PORT}...")
log(f"Listening on port {PORT}...")

conn, addr = s.accept()
print("Connected by:", addr)
log(f"Connected by: {addr}")

while True:
    # 轮回测试
    # cmd = input(">>> ")  # 输入要发送的内容
    # log(f"INPUT: {cmd}")

    # if not cmd:
    #     continue

    # conn.send(cmd.encode())

    # data = conn.recv(1024).decode()
    # print(data)
    # log(f"OUTPUT: {data}")


    # 单次测试
    cmd = "ls /"
    log(f"INPUT: {cmd}")

    if not cmd:
        continue

    conn.send(cmd.encode())

    data = conn.recv(1024).decode()
    print(data)
    log(f"OUTPUT: {data}")

    break
    
conn.close()
s.close()