// A simple long-running Node.js application for testing
setTimeout(() => {}, 1000 * 1000);