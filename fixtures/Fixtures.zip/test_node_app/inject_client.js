const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');

const code = fs.readFileSync('/root/workspace/test_node_app/inject.js', 'utf8');

http.get('http://127.0.0.1:61000/json', (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
        const targets = JSON.parse(data);
        const wsUrl = targets[0].webSocketDebuggerUrl;
        console.log('Connecting to:', wsUrl);

        const ws = new WebSocket(wsUrl);
        ws.on('open', () => {
            ws.send(JSON.stringify({
                id: 1,
                method: 'Runtime.evaluate',
                params: { expression: code }
            }));
        });
        ws.on('message', (data) => {
            console.log('Response:', data.toString());
            ws.close();
        });
        ws.on('error', (err) => {
            console.error('WebSocket error:', err.message);
        });
    });
}).on('error', (err) => {
    console.error('HTTP error:', err.message);
});